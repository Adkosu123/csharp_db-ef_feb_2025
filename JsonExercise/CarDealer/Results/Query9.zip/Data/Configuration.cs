﻿namespace CarDealer.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-DLVNAS7;Database=CarDealer2025;Integrated Security=True;Encrypt=False";
    }
}
