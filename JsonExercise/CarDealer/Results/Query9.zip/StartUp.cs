﻿using CarDealer.Data;
using CarDealer.Models;
using Newtonsoft.Json;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main()
        {
            using CarDealerContext dbContext = new CarDealerContext();

            string jsonString = File.ReadAllText("../../../Datasets/suppliers.json");

           string result = ImportSuppliers(dbContext, jsonString);

			Console.WriteLine(result);
		}




        public static string ImportSuppliers(CarDealerContext context, string inputJson) 
        {
			var suppliers = JsonConvert.DeserializeObject<List<Supplier>>(inputJson);

			context.Suppliers.AddRange(suppliers);
			context.SaveChanges();

            string result = $"Successfully imported {suppliers.Count}.";

            return result;

		}
    }
}